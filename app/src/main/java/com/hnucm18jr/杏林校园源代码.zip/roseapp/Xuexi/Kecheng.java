package com.hnucm18jr.roseapp.Xuexi;

public class Kecheng {
    public String title;
    public String name;
    public String time;
    public  int image;
}

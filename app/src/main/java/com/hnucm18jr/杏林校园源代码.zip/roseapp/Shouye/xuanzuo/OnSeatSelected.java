package com.hnucm18jr.roseapp.Shouye.xuanzuo;

/**
 * Created by chandrasekar on 14/02/16.
 */
public interface OnSeatSelected {

    void onSeatSelected(int count);
}

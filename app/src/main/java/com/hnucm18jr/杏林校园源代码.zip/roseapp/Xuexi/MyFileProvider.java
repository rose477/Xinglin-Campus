package com.hnucm18jr.roseapp.Xuexi;

import androidx.core.content.FileProvider;

public class MyFileProvider extends FileProvider {
}

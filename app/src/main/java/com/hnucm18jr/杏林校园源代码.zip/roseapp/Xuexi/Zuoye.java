package com.hnucm18jr.roseapp.Xuexi;

public class Zuoye {
    public String title;
    public String name;
    public String time;

}

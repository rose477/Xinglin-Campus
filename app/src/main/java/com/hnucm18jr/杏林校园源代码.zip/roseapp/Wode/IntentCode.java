package com.hnucm18jr.roseapp.Wode;

public class IntentCode  {
    private int code;// code码
    private String text;// 消息

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return text;
    }

    public void setMessage( String text) {
        this.text = text;
    }
}

package com.hnucm18jr.roseapp.Shouye.ershou;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.hnucm18jr.roseapp.R;

public class SellActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);
    }
}